< !DOCTYPE html > < html lang = "es" >
    <
    head >
    <
    meta charset = "UTF-8" >
    <
    meta name = "viewport"
content = "width=device-width, initial-scale=1.0" >
    <
    title > Número Secreto < /title> <
style >
    body {
        font - family: Arial, sans - serif;
        text - align: center;
    }
input {
    margin: 10 px;padding: 5 px;
}
button {
    padding: 10 px;cursor: pointer;
} <
/style> < /
head > <
    body >
    <
    h1 > Juego del Número Secreto < /h1> <
p > Introduce un número del 1 al 10: < /p> <
input type = "number"
id = "numero"
min = "1"
max = "10" >
    <
    button onclick = "adivinar()" > Intentar < /button> <
button onclick = "nuevoJuego()" > Nuevo Juego < /button> <
p id = "mensaje" > < /p> <
script >
    let numeroSecreto = Math.floor(Math.random() * 10) + 1;
let intentos = 0;

function adivinar() {
    let numeroIngresado = document.getElementById("numero").value;
    if (numeroIngresado === "") {
        alert("Por favor, ingresa un número.");
        return;
    }

    intentos++;
    numeroIngresado = parseInt(numeroIngresado);
    let mensaje = document.getElementById("mensaje");

    if (numeroIngresado < numeroSecreto) {
        mensaje.textContent = "El número secreto es mayor.";
    } else if (numeroIngresado > numeroSecreto) {
        mensaje.textContent = "El número secreto es menor.";
    } else {
        mensaje.textContent = `¡Felicidades! Adivinaste el número en ${intentos} intento(s).`;
    }

    document.getElementById("numero").value = "";
}

function nuevoJuego() {
    numeroSecreto = Math.floor(Math.random() * 10) + 1;
    intentos = 0;
    document.getElementById("mensaje").textContent = "";
    document.getElementById("numero").value = "";
} <
/script>

<
/body> < /
html >